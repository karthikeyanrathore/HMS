DROP TABLE IF EXISTS product;

CREATE TABLE product (
	id INTEGER,
	name TEXT,
	price INTEGER,
	stock INTEGER
);








